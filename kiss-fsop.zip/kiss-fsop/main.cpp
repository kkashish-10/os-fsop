/**
 * @file main.cpp
 * @author ddos_kas (kd372744@gmail.com)
 * @brief
 * @version 0.1
 * @date 2022-06-03
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <stdlib.h>

int main(int argc, char **argv)
{
    

    // return exit success everything went smooth
    return EXIT_SUCCESS;
}